-- MySQL dump 10.14  Distrib 5.5.65-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: malcantara_proyecto
-- ------------------------------------------------------
-- Server version	5.5.65-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `malcantara_proyecto`
--


--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulos` (
  `id_artic` int(11) NOT NULL AUTO_INCREMENT,
  `ISSN` int(8) NOT NULL,
  `autor` varchar(45) NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `revista` varchar(45) NOT NULL,
  `anio` int(11) DEFAULT NULL,
  `mes` int(11) DEFAULT NULL,
  `pag_ini` int(11) DEFAULT NULL,
  `pag_fin` int(11) DEFAULT NULL,
  `user_artic` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_artic`),
  UNIQUE KEY `id_artic_UNIQUE` (`id_artic`),
  KEY `user_artic_idx` (`user_artic`),
  CONSTRAINT `user_artic` FOREIGN KEY (`user_artic`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulos`
--

LOCK TABLES `articulos` WRITE;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` VALUES (1,24622737,'Joaquim Prats y Roberto Fernandez','Explicacion objetiva sobre la realidad social','Historia y epistemologia',2016,11,97,110,1),(2,20147694,'Joaquim Prats','Combates por la historia de la educacion','Debates',2015,7,145,153,1),(3,16992407,'Tomas Baiget','El profesional de la informacion','TK',2006,5,131,136,1),(4,1131558,'Eduardo Leste Moyano','Identidad, memoria y nostalgia de la escena','Antropología social',2018,10,1,15,1),(5,1131559,'Ignacio Elpidio','Bourdieu en el World Pride 2017','Antropologia social',2019,6,47,62,1);
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `libros`
--

DROP TABLE IF EXISTS `libros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `libros` (
  `id_libro` int(11) NOT NULL AUTO_INCREMENT,
  `ISBN` bigint(13) NOT NULL,
  `autor` varchar(45) NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `editorial` varchar(45) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `n_paginas` int(11) DEFAULT NULL,
  `user_libro` int(11) NOT NULL,
  PRIMARY KEY (`id_libro`),
  UNIQUE KEY `id_libro_UNIQUE` (`id_libro`),
  KEY `user_libro_idx` (`user_libro`),
  CONSTRAINT `user_libro` FOREIGN KEY (`user_libro`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libros`
--

LOCK TABLES `libros` WRITE;
/*!40000 ALTER TABLE `libros` DISABLE KEYS */;
INSERT INTO `libros` VALUES (9,9798625710190,'Carlos Calvo','Viajes del Zid','Independiente',2020,525,1),(11,9781520995748,'Ivan Gilabert','Diario del Viajero','Independiente',2017,370,1),(12,9788498726138,'Brian Sanderson','El imperio final','Ediciones B',2019,688,1),(13,9788499082479,'Patrick Rothfuss','El nombre del viento','Debolsillo',2011,880,1);
/*!40000 ALTER TABLE `libros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas`
--

DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notas` (
  `id_nota` int(11) NOT NULL AUTO_INCREMENT,
  `tema` varchar(70) NOT NULL,
  `contenido` varchar(600) DEFAULT NULL,
  `user_nota` int(11) NOT NULL,
  `id_libro` int(11) DEFAULT NULL,
  `id_artic` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_nota`),
  KEY `user_nota_idx` (`user_nota`),
  KEY `id_libro_idx` (`id_libro`),
  KEY `id_artic_idx` (`id_artic`),
  CONSTRAINT `id_artic` FOREIGN KEY (`id_artic`) REFERENCES `articulos` (`id_artic`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `id_libro` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id_libro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_nota` FOREIGN KEY (`user_nota`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas`
--

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
INSERT INTO `notas` VALUES (1,'Literatura Z','El libro va sobre el personaje del Cid convertido en zombie.',1,9,NULL),(2,'Original','Es una historia bastante original.',1,9,NULL),(3,'Fantasia heroica','Al nivel de Juego de Tronos.',1,12,NULL);
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `correo` varchar(60) DEFAULT NULL,
  `last_session` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'miguel','75004f149038473757da0be07ef76dd4a9bdbc8d','miguel','miguel@mail.com','2020-05-16 22:23:35'),(2,'maria','e21fc56c1a272b630e0d1439079d0598cf8b8329','maria','maria@mail.com','0000-00-00 00:00:00'),(3,'ruso','3cd2b9eb8a38a346299e121f84e9d9112619bf7f','ruso','ruso@mail.com','0000-00-00 00:00:00'),(4,'pepe','265392dc2782778664cc9d56c8e3cd9956661bb0','pepe','pepe@mail.com','0000-00-00 00:00:00'),(5,'alvaro','5b2d0c210c4a9fd6aeaf2eaedf8273be993c90c2','alvaro','alvaro@mail.com','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`malcantara`@`%`*/ /*!50003 TRIGGER `malcantara_proyecto`.`usuarios_BEFORE_INSERT` BEFORE INSERT ON `usuarios` FOR EACH ROW
BEGIN
	CALL validar_correo(NEW.`correo`);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`malcantara`@`%`*/ /*!50003 TRIGGER `malcantara_proyecto`.`usuarios_BEFORE_UPDATE` BEFORE UPDATE ON `usuarios` FOR EACH ROW
BEGIN
	CALL validar_correo(NEW.`correo`);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-17 15:14:51

/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`malcantara`@`%` PROCEDURE `insert_articulo`(IN val_ISSN VARCHAR(9), val_autor VARCHAR(45), val_titulo VARCHAR(45), val_revista VARCHAR(45), val_anio INT, val_mes INT, val_pag_ini INT, val_pag_fin INT, val_user_artic INT)
BEGIN
	INSERT INTO articulos(ISSN,autor,titulo,revista,anio,mes,pag_ini,pag_fin,user_artic) VALUES (val_ISSN,val_autor,val_titulo,val_revista,val_anio,val_mes,val_pag_ini,val_pag_fin,val_user_artic);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`malcantara`@`%` PROCEDURE `insert_libro`(IN val_ISBN VARCHAR(14), val_autor VARCHAR(45), val_titulo VARCHAR(45), val_editorial VARCHAR(45), val_anio INT, val_n_paginas INT, val_user_libro INT)
BEGIN
	INSERT INTO libros(ISBN,autor,titulo,editorial,anio,n_paginas,user_libro) VALUES (val_ISBN,val_autor,val_titulo,val_editorial,val_anio,val_n_paginas,val_user_libro);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`malcantara`@`%` PROCEDURE `insert_nota`(val_tema VARCHAR(45), val_contenido VARCHAR(600), val_user_nota INT, val_id_libro INT, val_id_artic INT)
BEGIN
	INSERT INTO notas(tema, contenido, user_nota, id_libro, id_artic) VALUES(val_tema,val_contenido,val_user_nota,val_id_libro,val_id_artic);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`malcantara`@`%` PROCEDURE `insert_usuario`(val_usuario VARCHAR(45), val_password VARCHAR(45), val_nombre VARCHAR(45), val_correo VARCHAR(60))
BEGIN
	INSERT INTO usuarios(usuario, password, nombre, correo) VALUES (val_usuario, val_password, val_nombre, val_correo);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`malcantara`@`%` PROCEDURE `validar_correo`(IN correo VARCHAR(60))
BEGIN
		IF correo NOT REGEXP '^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$' THEN
		SIGNAL SQLSTATE VALUE '45000'
		SET MESSAGE_TEXT = '[table:usuarios] - `correo` column is not valid';
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
